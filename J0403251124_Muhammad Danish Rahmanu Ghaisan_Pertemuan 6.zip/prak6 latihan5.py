#==========================================
# Nama: Muhammad Danish Rahmanu Ghaisan
# NIM: J0403251124
# Kelas: TPL B2
#==========================================



def merge(left, right):
    result = []
    i = 0
    j = 0

    # Loop berjalan selama kedua sub-list masih memiliki elemen
    while i < len(left) and j < len(right):
        
        # Kondisi agar Ascending (Kecil ke Besar) adalah 'left[i] < right[j]'
        # Kita membandingkan elemen di list kiri dan kanan, lalu mengambil yang terkecil.
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    # Fungsi result.extend()
    # Setelah loop 'while' di atas selesai, salah satu list (left atau right) 
    # pasti masih memiliki sisa elemen yang belum dimasukkan ke 'result'.
    # extend() berfungsi untuk menambahkan semua sisa elemen tersebut 
    # sekaligus ke bagian akhir list 'result'.
    result.extend(left[i:])
    result.extend(right[j:])

    return result



'''
# Loop berjalan selama kedua sub-list masih memiliki elemen
# Kondisi agar Ascending (Kecil ke Besar) adalah 'left[i] < right[j]'
# Kita membandingkan elemen di list kiri dan kanan, lalu mengambil yang terkecil.
# Fungsi result.extend()
# Setelah loop 'while' di atas selesai, salah satu list (left atau right) 
# pasti masih memiliki sisa elemen yang belum dimasukkan ke 'result'.
# extend() berfungsi untuk menambahkan semua sisa elemen tersebut 
# sekaligus ke bagian akhir list 'result'.
'''