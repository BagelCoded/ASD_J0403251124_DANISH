#==========================================
# Nama: Muhammad Danish Rahmanu Ghaisan
# NIM: J0403251124
# Kelas: TPL B2
#==========================================



def insertion_sort(data):
    for i in range(1, len(data)):
        key = data[i]
        j = i - 1

        #Agar Ascending (Kecil ke Besar), kondisinya adalah: data[j] > key
        # Kita terus menggeser angka ke kanan selama angka di kiri LEBIH BESAR dari key.
        while j >= 0 and data[j] > key: 
            data[j + 1] = data[j]
            j -= 1

        #Letakkan 'key' di posisi yang sudah kosong/benar setelah pergeseran
        data[j + 1] = key

    return data

# Uji coba
angka = [12, 11, 13, 5, 6]
print(f"Hasil Ascending: {insertion_sort(angka)}")

'''
    #Agar Ascending (Kecil ke Besar), kondisinya adalah: data[j] > key
    #Kita terus menggeser angka ke kanan selama angka di kiri LEBIH BESAR dari key.
    #Letakkan 'key' di posisi yang sudah kosong/benar setelah pergeseran
'''