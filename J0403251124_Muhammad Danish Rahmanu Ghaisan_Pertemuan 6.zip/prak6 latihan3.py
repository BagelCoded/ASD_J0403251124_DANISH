#==========================================
# Nama: Muhammad Danish Rahmanu Ghaisan
# NIM: J0403251124
# Kelas: TPL B2
#==========================================



def insertion_sort(data):
    # Data awal: [5, 2, 4, 6, 1, 3]
    
    for i in range(1, len(data)):
        key = data[i]
        j = i - 1
        
        # Variabel untuk menghitung jumlah pergeseran (untuk menjawab soal no 3)
        shifts_in_this_iteration = 0
        
        while j >= 0 and data[j] > key:
            data[j + 1] = data[j]
            j -= 1
            shifts_in_this_iteration += 1
            
        data[j + 1] = key
        
        
        #Tuliskan isi list setelah iterasi i = 1
        if i == 1:
            # Penjelasan: key adalah 2. 5 > 2, maka 5 geser ke kanan. 2 masuk ke depan.
            # Hasil: [2, 5, 4, 6, 1, 3]
            print(f"Hasil setelah i = 1: {data}")
            
        #Tuliskan isi list setelah iterasi i = 3
        if i == 3:
            # Penjelasan: i=2 menghasilkan [2, 4, 5, 6, 1, 3]
            # Pada i=3, key adalah 6. Karena 5 < 6, tidak ada pergeseran.
            # Hasil: [2, 4, 5, 6, 1, 3]
            print(f"Hasil setelah i = 3: {data}")
            
        #Berapa kali pergeseran terjadi pada iterasi i = 4?
        if i == 4:
            # Penjelasan: List saat ini adalah [2, 4, 5, 6, 1, 3]. key adalah 1 (indeks 4).
            # Angka 1 harus melewati 6, 5, 4, dan 2 untuk sampai ke posisi paling depan.
            # Setiap angka yang dilewati terhitung sebagai 1 pergeseran (shifting).
            print(f"Jumlah pergeseran pada i = 4: {shifts_in_this_iteration} kali")

    return data

# Eksekusi program
data_input = [5, 2, 4, 6, 1, 3]
hasil = insertion_sort(data_input)
print(f"Hasil Akhir: {hasil}")

'''
# Data awal: [5, 2, 4, 6, 1, 3]
# Variabel untuk menghitung jumlah pergeseran (untuk menjawab soal no 3)
#Tuliskan isi list setelah iterasi i = 1
    # Penjelasan: key adalah 2. 5 > 2, maka 5 geser ke kanan. 2 masuk ke depan.
    # Hasil: [2, 5, 4, 6, 1, 3]
#Tuliskan isi list setelah iterasi i = 3
    # Penjelasan: i=2 menghasilkan [2, 4, 5, 6, 1, 3]
    # Pada i=3, key adalah 6. Karena 5 < 6, tidak ada pergeseran.
    # Hasil: [2, 4, 5, 6, 1, 3]
#Berapa kali pergeseran terjadi pada iterasi i = 4?
    # Penjelasan: List saat ini adalah [2, 4, 5, 6, 1, 3]. key adalah 1 (indeks 4).
    # Angka 1 harus melewati 6, 5, 4, dan 2 untuk sampai ke posisi paling depan.
    # Setiap angka yang dilewati terhitung sebagai 1 pergeseran (shifting).
'''