#==========================================
# Nama: Muhammad Danish Rahmanu Ghaisan
# NIM: J0403251124
# Kelas: TPL B2
#==========================================



def insertion_sort(data):
    for i in range(1, len(data)):
        
        key = data[i]
        j = i-1

        while j>=0 and data[j] > key:
            data[j+1] = data[j]
            j -= 1
        data[j+1] = key
    
    return data

angka = [7,8,5,2,4,6]
print ("Hasil Sorting: ", insertion_sort(angka))