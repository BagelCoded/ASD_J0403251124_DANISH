#==========================================
# Nama: Muhammad Danish Rahmanu Ghaisan
# NIM: J0403251124
# Kelas: TPL B2
#==========================================



def merge_sort(data):
    # BASE CASE: Kondisi di mana rekursi harus BERHENTI.
    # Jika panjang list adalah 0 atau 1, berarti data sudah dianggap terurut.
    # Tanpa ini, fungsi akan terus memanggil dirinya sendiri selamanya (infinite recursion).
    if len(data) <= 1:
        return data

    # Membagi data menjadi dua bagian (Divide)
    mid = len(data) // 2
    left = data[:mid]
    right = data[mid:]

    # REKURSI: Mengapa memanggil diri sendiri? 
    # Karena Merge Sort menggunakan prinsip 'Divide and Conquer'.
    # Fungsi memanggil dirinya sendiri untuk terus membagi list besar menjadi 
    # potongan-potongan kecil sampai mencapai base case.
    left_sorted = merge_sort(left)
    right_sorted = merge_sort(right)

    # FUNGSI MERGE(): Tujuannya adalah menggabungkan (combine).
    # Setelah data dipecah kecil-kecil, merge() bertugas menyatukan kembali 
    # dua list yang sudah terurut (left_sorted & right_sorted) menjadi satu 
    # list baru yang urutannya benar-benar sinkron (Ascending/Descending).
    return merge(left_sorted, right_sorted)

def merge(left, right):
    # Logika sederhana penggabungan dua list terurut
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

# Contoh penggunaan:
data_tes = [38, 27, 43, 3, 9, 82, 10]
print(f"Hasil Merge Sort: {merge_sort(data_tes)}")



'''
# BASE CASE: Kondisi di mana rekursi harus BERHENTI.
    # Jika panjang list adalah 0 atau 1, berarti data sudah dianggap terurut.
    # Tanpa ini, fungsi akan terus memanggil dirinya sendiri selamanya (infinite recursion).
# REKURSI: Mengapa memanggil diri sendiri? 
    # Karena Merge Sort menggunakan prinsip 'Divide and Conquer'.
    # Fungsi memanggil dirinya sendiri untuk terus membagi list besar menjadi 
    # potongan-potongan kecil sampai mencapai base case.
# FUNGSI MERGE(): Tujuannya adalah menggabungkan (combine).
    # Setelah data dipecah kecil-kecil, merge() bertugas menyatukan kembali 
    # dua list yang sudah terurut (left_sorted & right_sorted) menjadi satu 
    # list baru yang urutannya benar-benar sinkron (Ascending/Descending).
'''