#==========================================
# Nama: Muhammad Danish Rahmanu Ghaisan
# NIM: J0403251124
# Kelas: TPL B2
#==========================================



def insertion_sort(data):
    # 1. Mulai dari indeks 1 karena elemen pertama (indeks 0) dianggap sudah terurut.
    # Kita mengambil elemen kedua untuk mulai dibandingkan ke arah kiri.
    for i in range(1, len(data)):
        
        # 2. 'key' menyimpan nilai yang sedang ditarik keluar dari barisan.
        # Tujuannya agar nilainya tidak hilang/tertimpa saat elemen lain digeser.
        key = data[i]
        j = i - 1

        # 3. 'while' digunakan karena jumlah langkah mundur ke kiri tidak tetap.
        # Loop akan berhenti otomatis begitu menemukan angka yang lebih kecil (kondisi dinamis).
        while j >= 0 and data[j] > key:
            
            # 4. Di dalam while terjadi operasi "Shifting" atau Pergeseran.
            # Elemen yang lebih besar digeser ke kanan untuk membuka celah bagi 'key'.
            data[j + 1] = data[j]
            j -= 1

        # Setelah celah ditemukan, 'key' diletakkan di posisi yang benar.
        data[j + 1] = key

    return data

# Contoh penggunaan:
angka = [9, 5, 1, 4, 3]
print(f"Hasil urut: {insertion_sort(angka)}")

'''
    # 1. Mulai dari indeks 1 karena elemen pertama (indeks 0) dianggap sudah terurut.
    # Kita mengambil elemen kedua untuk mulai dibandingkan ke arah kiri.
    # 2. 'key' menyimpan nilai yang sedang ditarik keluar dari barisan.
    # Tujuannya agar nilainya tidak hilang/tertimpa saat elemen lain digeser.
    # 3. 'while' digunakan karena jumlah langkah mundur ke kiri tidak tetap.
    # Loop akan berhenti otomatis begitu menemukan angka yang lebih kecil (kondisi dinamis).
    # 4. Di dalam while terjadi operasi "Shifting" atau Pergeseran.
    # Elemen yang lebih besar digeser ke kanan untuk membuka celah bagi 'key'.
'''