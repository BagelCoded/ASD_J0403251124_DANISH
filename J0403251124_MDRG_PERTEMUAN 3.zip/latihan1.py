def delete_node(self, key):
    # 1. Simpan head ke dalam variabel sementara
    temp = self.head

    # 2. Kasus Khusus: Jika node yang ingin dihapus adalah Head
    if temp and temp.data == key:
        self.head = temp.next  # Geser head ke node berikutnya
        temp = None            # Hapus node lama dari memori
        return

    # 3. Mencari node yang ingin dihapus (sambil melacak node sebelumnya)
    prev = None
    while temp and temp.data != key:
        prev = temp
        temp = temp.next

    # 4. Jika data tidak ditemukan di seluruh list
    if temp is None:
        print("Data tidak ditemukan dalam list.")
        return

    # 5. Putuskan koneksi node yang dihapus dari list
    # Hubungkan node sebelumnya langsung ke node setelah temp
    prev.next = temp.next
    temp = None