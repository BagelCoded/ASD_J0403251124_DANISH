class Node:	
    def	__init__(self,	data):	
        self.data = data	
        self.next = None	
class CircularSinglyLinkedList:	
    def	__init__(self):	
        self.head = None	
        self.tail = None # Tambahkan pointer tail	
    def	insert_at_end(self,	data):	
        new_node = Node(data)	
        if not self.head: # Jika linked list kosong	
            self.head = new_node
            self.tail = new_node	
            self.tail.next = self.head # Circular link ke dirinya sendiri	
        else:	
            self.tail.next = new_node # Sambungkan tail ke node baru	
            self.tail	=	new_node # Update tail ke node baru
            self.tail.next	=	self.head # Circular link kembali	ke head 4
    def	display(self):
        if	not	self.head:	
            print("List	is	empty")	
            return
        print("Circular Linked List Traversal:")	
        temp	=	self.head	
        print(temp.data,	end="	->	")	
        temp = temp.next	
        while temp != self.head:
            print(temp.data,	end="	->	")	
            temp = temp.next
            print("... (back to head)")	
# Contoh Penggunaan	
cll = CircularSinglyLinkedList()	
cll.insert_at_end(3)	
cll.insert_at_end(5)	
cll.insert_at_end(13)	
cll.insert_at_end(2)	
cll.display()