class Node: 
    def __init__(self, data): 
        self.data = data 
        self.next = None 
class LinkedList: 
    def __init__(self): 
        self.head = None 
        self.tail = None  # Tambahkan pointer tail 
    def insert_at_end(self, data): 
        new_node = Node(data) 
        if not self.head:  # Jika linked list kosong 
            self.head = new_node 
            self.tail = new_node  # Tail juga menunjuk ke node pertama 
        else: 
            self.tail.next = new_node  # Sambungkan tail ke node baru 
            self.tail = new_node  # Update tail ke node baru 
    def display(self): 
        temp = self.head 
        while temp: 
            print(temp.data, end=" -> ") 
            temp = temp.next 
            print("null") 
# Contoh Penggunaan 
ll = LinkedList() 
ll.insert_at_end() 
ll.insert_at_end() 
ll.insert_at_end() 
ll.insert_at_end() 
ll.display()