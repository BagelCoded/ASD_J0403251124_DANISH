class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class CircularSinglyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def insert_at_end(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            self.tail = new_node
            self.tail.next = self.head
        else:
            self.tail.next = new_node
            self.tail = new_node
            self.tail.next = self.head

    def search(self, key):
        # Skenario 3: List Kosong
        if not self.head:
            print("Circular Linked List kosong. Tidak ada elemen yang bisa dicari.")
            return

        temp = self.head
        found = False
        
        # Lakukan perulangan hingga kembali ke head
        while True:
            if temp.data == key:
                found = True
                break
            temp = temp.next
            if temp == self.head: # Sudah kembali ke awal
                break
        
        # Skenario 1 & 2: Ditemukan atau Tidak
        if found:
            print(f"Elemen {key} ditemukan dalam Circular Linked List.")
        else:
            print(f"Elemen {key} tidak ditemukan dalam Circular Linked List.")

# --- Pengujian Program ---

def jalankan_latihan():
    cll = CircularSinglyLinkedList()
    
    # Input elemen (Simulasi Contoh #1)
    elemen_input = [3, 7, 12, 19, 25]
    for el in elemen_input:
        cll.insert_at_end(el)
    
    print(f"Isi List: {elemen_input}")
    
    # Cari elemen
    target = 12
    print(f"Mencari elemen: {target}")
    cll.search(target)
    
    print("-" * 30)
    
    # Simulasi Contoh #2 (Data tidak ada)
    target_salah = 25 # (Jika list diisi 5, 10, 15, 20, 30)
    cll_dua = CircularSinglyLinkedList()
    for el in [5, 10, 15, 20, 30]: cll_dua.insert_at_end(el)
    cll_dua.search(25)

    print("-" * 30)

    # Simulasi Contoh #3 (List Kosong)
    cll_kosong = CircularSinglyLinkedList()
    cll_kosong.search(10)

jalankan_latihan()