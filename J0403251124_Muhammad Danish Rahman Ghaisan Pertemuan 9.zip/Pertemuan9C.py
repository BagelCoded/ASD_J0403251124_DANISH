# Nama : Muhammad Danish Rahmanu Ghaisan
# NIM : J0403251124
# Kelas : B2/P2

#Latihan 3 : Membuat Node

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None    #child kiri
        self.right = None   #child kanan

#Fungsi preorder : Root ==> Left ==> Right
def preorder(node):
    if node is not None:
        print(node.data, end=" ")
        preorder(node.left)
        preorder(node.right)

#membuat tree
root = Node("A")


#membuat child level 1
root.left = Node("B")
root.right = Node("C")

#membuat child leve 2
root.left.left = Node("D")
root.left.right = Node("E")

#menjalankan traversal preorder
print("Hasil Traversal Preorder")
preorder(root)
