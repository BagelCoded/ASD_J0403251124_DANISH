# Nama : Muhammad Danish Rahmanu Ghaisan
# NIM : J0403251124
# Kelas : B2/P2

#Latihan 2 : Membuat Binary Search Tree

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None    #child kiri
        self.right = None   #child kanan

#membuat sebuah node Root
root = Node("A")


#membuat child level 1
root.left = Node("B")
root.right = Node("C")

#membuat child leve 2
root.left.left = Node("D")
root.left.right = Node("E")


# Menampilkan isi node
print("Data pada root : ", root.data)
print("Child kiri root : ", root.left.data)
print("Child kanan root : ", root.right.data)
print("Child kiri dari B : ", root.left.left.data)
print("Child kanan dari B : ", root.left.right.data)

