# Nama : Muhammad Danish Rahmanu Ghaisan
# NIM : J0403251124
# Kelas : B2/P2

# Latihan 6: Struktur Organisasi Perusahaan

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None    #child kiri
        self.right = None   #child kanan

#Fungsi preorder : Root ==> Left ==> Right
def preorder(node):
    if node is not None:
        print(node.data, end=" ")
        preorder(node.left)
        preorder(node.right)


#membuat tree struktur organisasi
root = Node("Direktur")

#Child level 1
root.left = Node("Manajer A")
root.right = Node("Manajer B")

#child level 2
root.left.left = Node("Staff1")
root.left.right = Node("Staff2")

root.right.right = Node("Staff3")


#menjalankan traversal preorder
print("Hasil Traversal Preorder: ")
preorder(root)
