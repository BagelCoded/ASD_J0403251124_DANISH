# Nama : Muhammad Danish Rahmanu Ghaisan
# NIM : J0403251124
# Kelas : B2/P2

#Latihan 1 : Membuat Node

class Node:
    def __init__(self, data):
        self.data = data    #menyimpan nilai
        self.left = None    #child kiri
        self.right = None   #child kanan

#membuat root
root = Node("A")

#menampilkan isi node
print("Data pada root", root.data)
print("Child kiri root", root.left)
print("Child kanan root", root.right)