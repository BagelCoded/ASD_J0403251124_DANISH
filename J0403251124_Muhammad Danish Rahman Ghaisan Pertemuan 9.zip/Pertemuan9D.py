# Nama : Muhammad Danish Rahmanu Ghaisan
# NIM : J0403251124
# Kelas : B2/P2

#Latihan 4

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None    #child kiri
        self.right = None   #child kanan

#membuat fungsi inorder . left -> root -> right
def inorder(node):
    if node is not None:   
        inorder(node.left)
        inorder(node.data, end=" ")
        inorder(node.right)

#membuut tree
# Membuat sebuah node root
root = Node("A")

#membuat child level 1
root.left = Node("B")
root.right = Node("C")

#membuat child level 2
root.left.left = Node("D")
root.left.right = Node("E")

#menjalankan 