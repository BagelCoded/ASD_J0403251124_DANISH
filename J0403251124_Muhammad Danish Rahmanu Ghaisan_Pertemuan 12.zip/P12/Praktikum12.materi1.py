import heapq 

# Representasi Graph menggunakan Adjacency List (Daftar Tetangga)
# Struktur: { Node_Asal: { Node_Tujuan: Bobot/Jarak } }
graph = { 
    'A': {'B': 4, 'C': 2}, 
    'B': {'D': 5}, 
    'C': {'D': 1}, 
    'D': {} 
} 

def dijkstra(graph, start): 
    # 1. Inisialisasi: Anggap semua jarak ke node lain adalah tak terhingga (infinity)
    # karena kita belum tahu seberapa jauh mereka dari titik awal.
    distances = {node: float('inf') for node in graph} 
 
    # 2. Jarak dari titik mulai ke dirinya sendiri tentu saja 0.
    distances[start] = 0 
 
    # 3. Inisialisasi Priority Queue (Antrean Berprioritas).
    # Format: (jarak_kumulatif, nama_node). 
    # heapq akan selalu memastikan nilai terkecil berada di urutan paling depan.
    pq = [(0, start)] 
 
    while pq: 
        # Ambil node dengan jarak terkecil dari antrean
        current_distance, current_node = heapq.heappop(pq) 

        # Optimalisasi: Jika jarak yang baru diambil lebih besar dari jarak yang sudah dicatat,
        # maka kita abaikan (skip) karena kita sudah menemukan jalur yang lebih pendek sebelumnya.
        if current_distance > distances[current_node]:
            continue
 
        # 4. Periksa semua tetangga dari node yang saat ini sedang dikunjungi
        for neighbor, weight in graph[current_node].items(): 
 
            # Hitung total jarak baru: jarak ke node sekarang + bobot ke tetangganya
            distance = current_distance + weight 
 
            # 5. Relaksasi: Jika ditemukan jalur yang lebih pendek menuju tetangga tersebut
            if distance < distances[neighbor]: 
                # Update catatan jarak terpendek ke tetangga tersebut
                distances[neighbor] = distance 
                
                # Masukkan tetangga tersebut ke dalam antrean untuk diperiksa nanti
                heapq.heappush(pq, (distance, neighbor)) 
 
    return distances 

# --- Eksekusi Program ---
# Menghitung jarak terpendek dari titik 'A' ke semua titik lainnya
hasil = dijkstra(graph, 'A') 

print("Jarak terpendek dari node A ke node lainnya:")
for node, jarak in hasil.items():
    print(f"Ke node {node}: {jarak}")