def bellman_ford(graph, start):
    # 1. Inisialisasi: Set jarak semua simpul ke tak hingga (inf), 
    # kecuali simpul awal yang diset ke 0.
    distances = {node: float('inf') for node in graph}
    distances[start] = 0

    # 2. Relaksasi Berulang:
    # Algoritma ini berjalan sebanyak (V - 1) kali, di mana V adalah jumlah simpul.
    # Jalur terpendek tanpa siklus maksimal memiliki (V - 1) tepi.
    for _ in range(len(graph) - 1):
        # Periksa setiap simpul dalam graf
        for node in graph:
            # Periksa setiap tetangga dari simpul tersebut
            for neighbor, weight in graph[node].items():
                # Jika ditemukan jalur yang lebih pendek ke 'neighbor' melalui 'node',
                # perbarui nilai jaraknya.
                if distances[node] + weight < distances[neighbor]:
                    distances[neighbor] = distances[node] + weight

    # 3. Deteksi Siklus Negatif:
    # Langkah tambahan untuk memastikan tidak ada siklus yang total bobotnya negatif.
    # Jika kita masih bisa memperpendek jarak setelah (V-1) relaksasi, 
    # artinya ada siklus negatif yang akan membuat jarak menjadi -tak hingga.
    for node in graph:
        for neighbor, weight in graph[node].items():
            if distances[node] + weight < distances[neighbor]:
                print("Graf mengandung siklus bobot negatif!")
                return None

    return distances

# --- Contoh Penggunaan ---
# Representasi Graf menggunakan Dictionary (Adjacency List)
graph_data = {
    'A': {'B': -1, 'C': 4},
    'B': {'C': 3, 'D': 2, 'E': 2},
    'C': {},
    'D': {'B': 1, 'C': 5},
    'E': {'D': -3}
}

hasil = bellman_ford(graph_data, 'A')

if hasil:
    print("Jarak terpendek dari titik A:")
    for node, dist in hasil.items():
        print(f"Ke simpul {node}: {dist}")