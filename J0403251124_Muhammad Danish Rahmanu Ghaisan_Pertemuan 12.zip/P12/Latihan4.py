# ========================================================== 
# Latihan 4: Studi Kasus Jalur Terpendek Lokasi Kampus 
# Algoritma: Dijkstra 
# ========================================================== 
import heapq 

# Graph lokasi kampus 
# Bobot menunjukkan waktu tempuh dalam menit 
graph = { 
    'Gerbang': {'Perpustakaan': 6, 'Kantin': 2}, 
    'Perpustakaan': {'Lab': 3}, 
    'Kantin': {'Lab': 4, 'Aula': 7}, 
    'Lab': {'Aula': 1}, 
    'Aula': {} 
} 

def dijkstra(graph, start): 
    distances = {node: float('inf') for node in graph} 
    distances[start] = 0 
    priority_queue = [(0, start)] 
    
    while priority_queue: 
        current_distance, current_node = heapq.heappop(priority_queue) 
        
        if current_distance > distances[current_node]: 
            continue 
            
        for neighbor, weight in graph[current_node].items(): 
            distance = current_distance + weight 
            if distance < distances[neighbor]: 
                distances[neighbor] = distance 
                heapq.heappush(priority_queue, (distance, neighbor)) 
    return distances 

hasil = dijkstra(graph, 'Gerbang') 
print("Jarak terpendek dari Gerbang Kampus:") 
for lokasi, jarak in hasil.items(): 
    print(f"{lokasi} = {jarak} menit")

# Jawaban Analisis: 
# 1. Lokasi mana yang paling dekat dari Gerbang?
#    Jawaban: Kantin (dengan waktu tempuh 2 menit).

# 2. Berapa waktu tempuh terpendek dari Gerbang ke Aula?
#    Jawaban: 7 menit. 
#    Jalur: Gerbang -> Kantin -> Lab -> Aula (2 + 4 + 1 = 7). 
#    Bandingkan dengan jalur Gerbang -> Kantin -> Aula yang memakan waktu 9 menit.

# 3. Apakah jalur langsung selalu menghasilkan jarak paling kecil? Jelaskan.
#    Jawaban: Tidak selalu. Dalam graph ini, jalur dari Kantin ke Aula memiliki 
#    opsi langsung (9 menit) dan opsi transit melalui Lab (4+1=5 menit). 
#    Algoritma Dijkstra membuktikan bahwa jalur dengan lebih banyak titik (node) 
#    terkadang lebih efisien jika total bobotnya lebih kecil.

# 4. Mengapa Dijkstra cocok digunakan pada kasus lokasi kampus ini?
#    Jawaban: Dijkstra sangat efektif karena peta kampus memiliki struktur graph 
#    berarah dengan bobot (waktu tempuh) yang bernilai positif. Algoritma ini 
#    menjamin hasil yang optimal (paling singkat) untuk mencari jalur dari satu 
#    titik ke semua titik lainnya dalam lingkungan yang kompleks.