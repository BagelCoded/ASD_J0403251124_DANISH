# ========================================================== 
# Latihan 2: Implementasi Dijkstra 
# ========================================================== 
import heapq 
# Weighted graph dengan bobot positif 
graph = {  
    'A': {'B': 4, 'C': 2}, 
    'B': {'D': 5}, 
    'C': {'D': 1}, 
    'D': {} 
}
def dijkstra(graph, start): 
    """ 
    Fungsi untuk mencari jarak terpendek dari node start 
    ke seluruh node lain menggunakan algoritma Dijkstra. 
    """ 
    # Semua jarak awal dibuat tak hingga 
    distances = {node: float('inf') for node in graph} 
    # Jarak dari start ke start adalah 0 
    distances[start] = 0 
    # Priority queue menyimpan pasangan (jarak, node) 
    priority_queue = [(0, start)] 
    
    while priority_queue: 
        current_distance, current_node = heapq.heappop(priority_queue) 
 
        # Jika jarak saat ini lebih besar dari jarak yang sudah tercatat, 
        # maka proses dilewati 
        if current_distance > distances[current_node]: 
            continue 
 
        # Periksa semua tetangga dari node saat ini 
        for neighbor, weight in graph[current_node].items(): 
            distance = current_distance + weight 
 
            # Jika ditemukan jarak yang lebih kecil, perbarui jaraknya 
            if distance < distances[neighbor]: 
                distances[neighbor] = distance 
                heapq.heappush(priority_queue, (distance, neighbor)) 
 
    return distances 
 
 
hasil = dijkstra(graph, 'A')

print("Jarak terpendek dari node A:") 
for node, distance in hasil.items(): 
    print(node, "=", distance)

# Jawaban Analisis: 
# 1. Jarak terpendek dari A ke B adalah 4.
# 2. Jarak terpendek dari A ke C adalah 2.
# 3. Jarak terpendek dari A ke D adalah 3.
# 4. Karena total akumulasi bobot melalui C (A->C + C->D = 2 + 1 = 3) lebih kecil 
#    daripada melalui B (A->B + B->D = 4 + 5 = 9).
# 5. Fungsi priority_queue adalah untuk memastikan bahwa algoritma selalu memproses 
#    node dengan jarak akumulasi terkecil terlebih dahulu (greedy approach), sehingga 
#    pencarian jalur menjadi efisien.
# 6. Dijkstra tidak cocok untuk bobot negatif karena algoritma ini berasumsi bahwa 
#    sekali sebuah node dikunjungi dan jaraknya ditentukan, jarak tersebut tidak akan 
#    berkurang lagi. Bobot negatif bisa menyebabkan jalur yang sudah dianggap "final" 
#    menjadi tidak valid dan bisa menjebak algoritma dalam loop yang tak berujung 
#    (negative cycle).