# 
#Latihan 1: Weighted Graph dan Perhitungan Jalur
# 
graph = {
    'A': {'B': 4, 'C': 2},
    'B': {'D': 5},
    'C': {'D': 1},
    'D': {}
}

# Menghitung dua kemungkinan jalur dari A ke D
jalur_1 = graph['A']['B'] + graph['B']['D'] #A -> B -> D
jalur_2 = graph['A']['C' ] + graph['C' ]['D']

print("Jalur 1: A -> B -> D =", jalur_1)
print("Jalur 2: A -> C -> D =", jalur_2)

# A -> C -> D

if jalur_1 < jalur_2:
    print("Jalur terpendek adalah A -> B -> D")
else:
    print("Jalur terpendek adalah A -> C -> D")

#Tuliskan jawaban sebagai komentar di bagian bawah program.
# Jawaban Analisis:
# 1. Total bobot jalur A -> B -> D adalah 9 (didapat dari 4 + 5).
# 2. Total bobot jalur A -> C -> D adalah 3 (didapat dari 2 + 1).
# 3. Jalur yang dipilih sebagai jalur terpendek adalah A -> C -> D.
# 4. Jalur terpendek tidak selalu ditentukan dari jumlah edge paling sedikit karena dalam "weighted graph", 
#    setiap edge memiliki nilai/biaya (cost) yang berbeda. Meskipun jumlah edge-nya sama atau lebih banyak, 
#    akumulasi bobot yang lebih kecil akan tetap dianggap sebagai jalur paling efisien (terpendek).