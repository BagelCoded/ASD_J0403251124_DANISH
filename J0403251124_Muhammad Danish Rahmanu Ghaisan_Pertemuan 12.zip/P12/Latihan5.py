import heapq

# 1. Representasi graph berbobot menggunakan dictionary
# Struktur: {Asal: {Tujuan: Bobot}}
graph = {
    'Bogor': {'Jakarta': 5, 'Depok': 2},
    'Depok': {'Jakarta': 2, 'Bandung': 6},
    'Jakarta': {'Bandung': 7},
    'Bandung': {}
}

# 2. Fungsi Dijkstra
def dijkstra(graph, start_node):
    # Inisialisasi jarak semua kota dengan tak terhingga (inf)
    distances = {node: float('inf') for node in graph}
    # Jarak ke kota asal sendiri adalah 0
    distances[start_node] = 0
    
    # Priority queue untuk menyimpan (jarak_saat_ini, nama_node)
    # heapq di Python menggunakan min-heap secara default
    priority_queue = [(0, start_node)]
    
    while priority_queue:
        # Ambil node dengan jarak terkecil dari queue
        current_distance, current_node = heapq.heappop(priority_queue)
        
        # Jika jarak yang ditemukan lebih besar dari yang sudah tercatat, abaikan
        if current_distance > distances[current_node]:
            continue
            
        # Periksa tetangga dari node yang sedang diproses
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            
            # Jika ditemukan jalur yang lebih pendek ke tetangga tersebut
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))
                
    return distances

# 3. Penentuan node awal (Start Node)
node_awal = 'Bogor'
hasil_jarak = dijkstra(graph, node_awal)

# 4. Output jarak terpendek dari node awal ke semua node
print(f"Jarak terpendek dari {node_awal}:")
for kota, jarak in hasil_jarak.items():
    print(f"{node_awal} -> {kota} = {jarak}")

# ==========================================================
# Jawaban Analisis: 
# ==========================================================
# 1. Node awal yang digunakan apa? 
#    Jawaban: Node awal yang digunakan adalah 'Bogor'.

# 2. Node mana yang memiliki jarak paling kecil dari node awal? 
#    Jawaban: Node 'Depok' (jarak = 2), jika mengesampingkan node awal itu sendiri.

# 3. Node mana yang memiliki jarak paling besar dari node awal? 
#    Jawaban: Node 'Bandung' (jarak = 8).

# 4. Jelaskan bagaimana algoritma Dijkstra bekerja pada kasus yang Anda buat.
#    - Algoritma mulai dari Bogor (0).
#    - Dari Bogor, ada dua pilihan: Jakarta (5) dan Depok (2). Dijkstra memilih Depok karena lebih kecil.
#    - Dari Depok, algoritma mengeksplorasi Jakarta (2+2=4) dan Bandung (2+6=8).
#    - Karena jalur ke Jakarta melalui Depok (4) lebih kecil daripada jalur langsung Bogor-Jakarta (5), 
#      maka jarak Jakarta diperbarui menjadi 4.
#    - Terakhir, dari Jakarta ke Bandung butuh 7, sehingga total 4+7=11. Namun, jalur Depok-Bandung 
#      sudah memberikan nilai 8, yang mana lebih kecil, sehingga jarak ke Bandung tetap 8.
# ==========================================================