#==============================================
#Praktikum 1 : Konsep ADT dan File Handling
#Latihan Dasar 1A : Membaca seluruh isi file
#==============================================

#membuka file dengan mode read ("r")
with open("data_mahasiswa.txt", "r", encoding="utf=8") as file:
    isi_file = file.read()
print(isi_file)

print(" === Hasil Read === ")
print("Tipe Data:", type(isi_file))
print("Jumlah Karakter", len(isi_file))
print("Jumlah baris", isi_file.count("\n")+1)

#Memouka file per baris
print("\n\n == Membaca File per Baris === ")    
jumlah_baris = 0
with open("data_mahasiswa.txt","r", encoding="utf-8") as file:
    for baris in file:
        jumlah_baris = jumlah_baris + 1
        baris = baris. strip() #menghilangkan baris baru \n
        print("Baris ke-", jumlah_baris)
        print ("Isinya :", baris)

# =====================================================
#Praktikum 1 : Konsep ADT dan File Handling
#Latihan Dasar 2 : Parsing baris menjadi kolom data
# =====================================================

print("\n\n")
with open("data_mahasiswa.txt","r", encoding="utf-8") as file:
    for baris in file:
        baris = baris.strip()
        nim, nama, nilai = baris.split(",") #parsing data berdasarkan karakter ,
        print(f"NIM :", {nim}, "| Nama:", {nama}, "| Nilai:", {nilai})

#======================================================
#Praktikum 1 : Konsep ADT dan File Handling
#Latihan Dasar 3 : Membaca File dan Menyimpan ke List
#======================================================

data_list = [] # List untuk menampung data mahasiswa

with open("data_mahasiswa.txt","r", encoding="utf-8") as file:
    for baris in file:
        baris = baris.strip()
        nim1, nama1, nilai1, = baris.split(",")

        #Simpan sebagai list " [nim, nama, nilai]"
        data_list.append([nim1,nama1,int(nilai1)])

print("==== Data Mahasiswa dalam LIST ====")
print (data_list)

print(" ==== Jumlah Record dalam LIST ==== ")
print ("Jumlah Record", len(data_list))

print(" ==== Menampilkan Data Record Tertentu ==== ")
print ("Contoh Record pertama: ", data_list[0]) #Array dimulai dari 0

#==========================================================
#Praktikum 1 : Konsep ADT dan File Handling
#Latihan Dasar 4 : Membaca File dan Menyimpan di dictionary
#==========================================================

data_dict = {} #buat variabel untuk dictionary
with open("data_mahasiswa.txt","r", encoding="utf-8") as file:
    for baris in file:
        baris = baris. strip()
        nim2, nama2, nilai2, = baris.split(",")

        #Simpan data mahasiswa ke dictionary dengan key NIM
        data_dict[nim2] = {      #key
        "nama": nama2,           #value
        "nilai": int(nilai2)     #value
        }
print("===Data Mahasiswa Dalam Dictionary===")
print(data_dict)