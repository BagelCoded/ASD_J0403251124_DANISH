nama_file = "data_mahasiswa.txt"

#membuat fungsi membaca data mahasiswa
def baca_data_mahasiswa(nama_file):
    data_dict = {}
    with open("data_mahasiswa.txt", "r",encoding= "utf-8") as file:
        for baris in file: 
            baris = baris.strip()
            nim, nama, nilai = baris.split(",")

        #simpan data dalam dictionary (key, value)
            data_dict[nim] = {      #key
             "nama" : nama,         #value
              "nilai" : int(nilai)  #value
            }

    return data_dict

#memanggil fungsi baca_data mahasiswa
buka_data = baca_data_mahasiswa(nama_file)
#print("Jumlah data terbaca ", len(buka_data))

# =============================================================
# Praktikum 2: Konsep ADT dan File Handling (STUDI KASUS)
# Latihan 2: Membuat fungsi menampilkan data
# =============================================================

def tampilkan_data(data_dict):
    
    if len(data_dict) == 0:
        print("Data Kosong")
        return
    
    #Membuat Header Tabel
    print("\n==== Daftar Mahasiswa ====")
    print(f"{'NIM' : <10} | {'Nama' : <12} | {'Nilai' :>5}")
    print("-" * 32) #membuat garis header

    for nim in sorted(data_dict):
        nama=data_dict[nim]["nama"]
        nilai=data_dict[nim]["nilai"]
        print(f"{nim:<10} | {nama:<12} | {nilai:>5}")

#memanggil fungsi menapilkan data
#tampilkan_data(buka_data)

# =============================================================
# Praktikum 2: Konsep ADT dan File Handling (STUDI KASUS)
# Latihan 3: Membuat fungsi mencari data
# =============================================================

def cari_data(data_dict):
    nim_cari = input("Masukkan NIM yang ingin dicari: ").strip()

    if nim_cari in data_dict:
        nama = data_dict[nim_cari]["nama"]
        nilai = data_dict[nim_cari]["nilai"]

        print("\n===== Data Mahasiswa Ditemukan ====")
        print(f"NIM     : {nim_cari}")
        print(f"Nama    : {nama}")
        print(f"Nilai   : {nilai}")

    else:
        print("\nData tidak ditemukan")

# =============================================================
# Praktikum 2: Konsep ADT dan File Handling (STUDI KASUS)
# Latihan 4: Membuat fungsi update nilai
# =============================================================

def update_nilai(data_dict):
    nim = input("Masukkan NIM mahasiswa yang akan diupdate nilai ")

    if nim not in data_dict:
        print("NIM tidak ditemukan, upadte dibatalkan")
        return
    try:
        nilai_baru = int(input("Masukkan nilai baru (0-100): ").strip())
    except ValueError:
        print("Nilai harus berupa angka. Update dibatalkan")
        return
        
    if nilai_baru < 0 or nilai_baru > 100:
        print("Nilai harus antara rentang 0-100, update dibatalkan")
        
    nilai_lama = data_dict[nim]["nilai"]
    data_dict[nim]["nilai"] = nilai_baru

    print(f"update berhasil. Nilai{nim} berubah dari {nilai_lama} menjadi {nilai_baru}")

#update_nilai(buka_data)
# =============================================================
# Praktikum 2: Konsep ADT dan File Handling (STUDI KASUS)
# Latihan 5: Membuat fungsi menyimpan perubahan data ke file
# =============================================================


def simpan_data(nama_file,data_dict):
     with open(nama_file, "w", encoding="utf-8") as file:
        for nim in sorted(data_dict.keys()):
            nama = data_dict[nim]["nama"]
            nilai = data_dict[nim]["nilai"]
            file.write(f'{nim},{nama},{nilai}\n')

#simpan_data(nama_file,buka_data)
#print("Data berhasil disimpan")

# =============================================================
# Praktikum 2: Konsep ADT dan File Handling (STUDI KASUS)
# Latihan 6: Membuat menu
# =============================================================
def main():
     
     #menjalankan fungsi 1 load data
     buka_data = baca_data_mahasiswa(nama_file)

while True:
     print("\n==== Menu Data Mahasiswa")
     print("1. Tampilkan semua data")
     print("2. Cari data berdasarkan NIM")
     print("3. Update nilai mahasiswa")
     print("4. Simpan data ke file")
     print("0. Keluar")
     
     pilihan = input("Pilihan menu: ").strip()

     if pilihan == "1":
        tampilkan_data(buka_data)

     elif pilihan == "2":
          cari_data(buka_data)
    
     elif pilihan == "3":
          update_nilai(buka_data)
     elif pilihan == "4":
          simpan_data(nama_file,buka_data)
     elif pilihan == "0":
          print("Program selesai")
          break
     
     else:
          print("Pilihan tidak valid. Coba lagi")

     if __name__ == "__":
        main()