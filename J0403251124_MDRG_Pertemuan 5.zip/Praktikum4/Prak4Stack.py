#====================================
#Nama: Muhammad Danish Rahmanu Ghaisan
#NIM: J0403251124
#Date: 18/2/2026
#Class: B2
#====================================

#==============================================
#Implementasi Dasar : Node via Linked List
#==============================================




class Node:
    def __init__(self,data):
        self.data = data #store data
        self.next = None #pointer to the next note

#1) Create Node 1 per 1
NodeA = Node("A")
NodeB = Node("B")
NodeC = Node("C")

#2) Connect Node: A -> B -> C -> None
NodeA.next = NodeB
NodeB.next = NodeC

#3) Menentukan Node Pertama (head)
head = NodeA

#4) Traversal : menelusuri dari head sampai none
current = head
while current is not None:
    print(current.data)     #menampilkan data pada node saat ini
    current = current.next  #pindah ke node berikutnya

#==================================================
#Impelementasi Dasar : Linked List + Insert last
#==================================================

class LinkedList: #class implementasi stack
    def __init__(self):
        self.head = None #Initally Empty

    def insert_awal(self,data):
        #1) Create New Nodes
        nodeBaru = Node(data)

        #2) New Node replaces old Node
        nodeBaru.next = self.head

        #3) Head changes to New Node
        self.head = nodeBaru
    
    def hapus_awal(self): #pop in stack
        data_terhapus = self.head.data #peek in stack
        #moves messenger head
        self.head = self.head.next
        print("Node yang dihapus adalah :", data_terhapus)

    def tampilkan(self): #Impliment Traversal
        current = self.head
        while current is not None:
            print(current.data)
            current = current.next

print("=====New List=====")
ll = LinkedList() #Instantiation Object to Class Linked List
ll.insert_awal("X")
ll.insert_awal("Y")
ll.insert_awal("Z")
ll.tampilkan()
ll.hapus_awal()
ll.tampilkan()