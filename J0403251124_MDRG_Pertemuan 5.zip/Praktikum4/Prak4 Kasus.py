#=========================================================
#Nama: Muhammad Danish Rahmanu Ghaisan
#NIM: J0403251124
#Kelas: B2
#=========================================================

#1) Mendefinisikan Node (Unit dasar linked list)
class Node:
    def __init__(self, nim, nama): # Perbaikan: Gunakan double underscore __
        self.nim = nim 
        self.nama = nama 
        self.next = None 

#2) Mendefinisikan queue, terdiri dari front dan rear
class queueAkademik:
    def __init__(self): # Perbaikan: Hapus parameter nim, nama karena antrian awal kosong
        self.front = None
        self.rear = None

    def is_empty(self):
        return self.front is None
    
    # Menambahkan data baru ke bagian belakang (Rear)
    def enqueue(self, nim, nama): # Saran: typo 'enquene' diperbaiki jadi 'enqueue'
        NodeBaru = Node(nim, nama)
        if self.is_empty():
            self.front = NodeBaru
            self.rear = NodeBaru
            return
    
        self.rear.next = NodeBaru
        self.rear = NodeBaru

    # Menghapus data paling depan (memberikan layanan akademik)
    def dequeue(self):
        if self.is_empty():
            return None
    
        node_dilayani = self.front
        self.front = self.front.next
        
        if self.front is None:
            self.rear = None
        
        return node_dilayani
    
    def tampilkan(self):
        if self.is_empty():
            print("Antrian masih kosong.")
            return

        print("\nDaftar Antrian Layanan Mahasiswa (Front -> Rear):")
        current = self.front
        no = 1
        while current is not None:
            print(f"{no}. {current.nim} - {current.nama}")
            current = current.next
            no += 1 
        print("-" * 20)

#Program Utama
def main():
    # Perbaikan: Tambahkan () untuk membuat instance/objek
    q = queueAkademik() 

    while True:
        print("\n======= Sistem Antrian Akademik =======")
        print("1. Tambah Mahasiswa (Enqueue)")
        print("2. Layani Mahasiswa (Dequeue)")
        print("3. Lihat Antrian")
        print("4. Keluar")

        pilihan = input("Pilih menu (1-4) : ").strip()

        if pilihan == "1":
            nim = input("Masukkan Nim : ").strip()
            nama = input("Masukkan Nama : ").strip()
            q.enqueue(nim, nama)
            print(f"Mahasiswa {nama} berhasil ditambahkan.")
            
        elif pilihan == "2":
            dilayani = q.dequeue() # Perbaikan: Gunakan dequeue, bukan enqueue
            if dilayani:
                print(f"Mahasiswa Dilayani: {dilayani.nim} - {dilayani.nama}")
            else:
                print("Antrian kosong. Tidak ada mahasiswa yang dilayani.")
            
        elif pilihan == "3":
            q.tampilkan()

        elif pilihan == "4":
            print("Program Selesai. Terima Kasih")
            break
        else:
            print("Pilihan tidak valid. Silahkan coba lagi 1-4")

if __name__ == "__main__":
    main()