def buat_pin_unik(panjang, hasil=""):
    # Base Case: PIN sudah mencapai panjang 3 digit
    if len(hasil) == panjang:
        print("PIN:", hasil)
        return
    
    # Menjelajahi pilihan angka 0 sampai 2
    for angka in ["0", "1", "2"]:
        # CEK: Hanya tambahkan angka jika belum ada di dalam 'hasil'
        if angka not in hasil:
            buat_pin_unik(panjang, hasil + angka)

# Menjalankan program untuk PIN 3 digit
print("Daftar PIN Unik (Tanpa Perulangan Angka):")
buat_pin_unik(3)