def solve_backtracking(n, current_path, limit_ones):
    # PRUNING: Jika jumlah angka '1' sudah melebihi batas, hentikan cabang ini
    if current_path.count('1') > limit_ones:
        print(f"Pruning di node: {current_path} (Terlalu banyak angka 1)")
        return

    # BASE CASE: Jika panjang sudah mencapai n, kita temukan solusi
    if len(current_path) == n:
        print(f"Solusi ditemukan: {current_path}")
        return

    # EKSPLORASI: Mencoba menambah '0' kemudian '1'
    # Mencoba cabang 0
    solve_backtracking(n, current_path + '0', limit_ones)
    
    # Mencoba cabang 1
    solve_backtracking(n, current_path + '1', limit_ones)

# Menjalankan program untuk n=3 dengan batas maksimal satu angka '1'
print("Memulai Backtracking dengan Pruning...")
solve_backtracking(3, "", 1)