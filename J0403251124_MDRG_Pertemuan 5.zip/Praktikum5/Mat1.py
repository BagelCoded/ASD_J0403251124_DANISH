def faktorial(n):
    # 1. Base Case: Jika n adalah 0 atau 1, kembalikan 1
    if n <= 1:
        return 1
    
    # 2. Recursive Case: n dikali dengan fungsi itu sendiri (n-1)
    else:
        return n * faktorial(n - 1)

# Mencoba program
angka = 5
hasil = faktorial(angka)
print(f"Faktorial dari {angka} adalah {hasil}")