def hitung(n):
    # 1. Base Case: Berhenti jika n kurang dari 1
    if n < 1:
        print("Selesai!")
        return 
    
    # Menampilkan proses Stacking (Masuk)
    print(f"Masuk (Stacking): hitung({n})")
    
    # 2. Recursive Case
    hitung(n - 1)
    
    # Menampilkan proses Unwinding (Keluar)
    print(f"Keluar (Unwinding): hitung({n})")

# Menjalankan fungsi
hitung(3)