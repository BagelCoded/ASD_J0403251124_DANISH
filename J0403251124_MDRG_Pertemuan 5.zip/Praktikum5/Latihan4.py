def generate_kombinasi(n, hasil=""):
    # Base Case: Jika panjang string sudah sesuai target n
    if len(hasil) == n:
        print(hasil)
        return # Kembali ke percabangan sebelumnya
    
    # Recursive Case:
    # Pilihan 1: Tambahkan 'A' dan jelajahi lebih dalam
    generate_kombinasi(n, hasil + "A")
    
    # Pilihan 2: Tambahkan 'B' dan jelajahi lebih dalam
    generate_kombinasi(n, hasil + "B")

# Menjalankan fungsi untuk kombinasi sepanjang 2 karakter
print("Daftar Kombinasi:")
generate_kombinasi(2)