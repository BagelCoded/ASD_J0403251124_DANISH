def countdown(n):
    # Base Case: Kondisi berhenti
    if n == 0:
        print("Selesai")
        return
    
    # Bagian ini dieksekusi saat fungsi "masuk" ke tumpukan deeper
    print("Masuk:", n)
    
    # Pemanggilan rekursif
    countdown(n - 1)
    
    # Bagian ini hanya dieksekusi SETELAH fungsi di atasnya selesai (saat "keluar")
    print("Keluar:", n)

# Menjalankan program
countdown(3)