def jumlahkan_list(data, indeks=0):
    # 1. Base Case: Jika indeks sudah mencapai panjang list
    if indeks == len(data):
        return 0
    
    # 2. Recursive Step: Ambil elemen saat ini + panggil fungsi untuk indeks berikutnya
    return data[indeks] + jumlahkan_list(data, indeks + 1)

# Contoh penggunaan
angka = [2, 4, 6, 8]
hasil = jumlahkan_list(angka)

print(f"Total penjumlahan list {angka} adalah: {hasil}")