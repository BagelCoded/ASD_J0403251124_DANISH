def cari_maks(data, index=0):
    # Base Case: Jika index mencapai elemen terakhir dalam list
    if index == len(data) - 1:
        return data[index]
    
    # Recursive Case: Cari nilai maksimum dari elemen-elemen setelah index ini
    maks_dari_sisa = cari_maks(data, index + 1)
    
    # Bandingkan elemen saat ini dengan nilai maksimum yang ditemukan di sisa list
    if data[index] > maks_dari_sisa:
        return data[index]
    else:
        return maks_dari_sisa

# Data Uji
angka = [3, 7, 2, 9, 5]
hasil_maksimum = cari_maks(angka)

print(f"List Angka: {angka}")
print(f"Nilai maksimum: {hasil_maksimum}")