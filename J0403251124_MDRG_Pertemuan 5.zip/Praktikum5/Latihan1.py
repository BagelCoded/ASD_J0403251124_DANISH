def pangkat(a, n):
    # 1. Base Case: Jika pangkat adalah 0, kembalikan 1
    if n == 0:
        return 1
    
    # 2. Recursive Case: Kalikan basis (a) dengan hasil fungsi itu sendiri
    # dengan nilai pangkat yang dikurangi 1 (n-1)
    else:
        return a * pangkat(a, n - 1)

# Pengujian
basis = 2
eksponen = 4
hasil = pangkat(basis, eksponen)

print(f"Hasil dari {basis} pangkat {eksponen} adalah: {hasil}")