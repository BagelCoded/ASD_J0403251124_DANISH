def generate_binary(n, path=""):
    # 1. BASE CASE (Kondisi Berhenti)
    # Jika panjang string sudah mencapai n, kita cetak hasilnya
    if len(path) == n:
        print(f"Solusi ditemukan: {path}")
        return

    # 2. RECURSIVE STEP (Eksplorasi)
    # Kita mencoba dua pilihan untuk setiap posisi: '0' atau '1'
    for pilihan in ['0', '1']:
        # CHOOSE: Tambahkan pilihan ke jalur saat ini
        # EXPLORE: Panggil fungsi secara rekursif untuk posisi berikutnya
        generate_binary(n, path + pilihan)
        
        # UNCHOOSE: Secara implisit terjadi saat fungsi rekursif selesai 
        # dan kembali ke loop sebelumnya untuk mencoba pilihan berikutnya.
        # (Dalam string Python, kita tidak perlu menghapus karakter secara manual
        # karena string bersifat immutable).

# Menjalankan program untuk n = 3
print("Memulai Backtracking untuk n=3:")
generate_binary(3)